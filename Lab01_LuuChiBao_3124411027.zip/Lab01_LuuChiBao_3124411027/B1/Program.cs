﻿namespace B1
{
    public class Program
    {
        public void Input()
        {
            Console.Write("Nhap ho ten: ");
            string? name = Console.ReadLine();
            Console.WriteLine("Ten la: {0}", name);
        }
        public static void Main(string[] args)
        {
            Program name = new();
            name.Input();
        }
    }
}
